#1. Create the vectors

#a.
a <- 2:30

#b.
b <- 30:2

#c.
combined <- c(1,a,b[2:29],1)

#d.
dev <- c(4,6,3)

#e. 

vec.e <- rep(c(5,6,7),10)

vec.e

#f.

vec.f <- c(rep(c(5,6,7),10),5)

vec.f

#g.

vec.g <- rep(c(4,6,3),c(10,20,30))

