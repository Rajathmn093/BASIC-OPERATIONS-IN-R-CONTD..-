#2. Create a vector of the values of eX sin(x) at x = 3, 3.1, 3.2, , 6.

x <- seq(from=3,to=6,by=0.1)

val <- exp(x) * sin(x)
