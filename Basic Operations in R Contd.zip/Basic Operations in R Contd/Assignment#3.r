#3.

set.seed(100)
x <- sample (0:999, 250, replace=T)
y <- sample (0:999, 250, replace=T)


y[y>500]


which(y > 700)


which(x>400 & y>400)


length(x[x%%2 == 0])

