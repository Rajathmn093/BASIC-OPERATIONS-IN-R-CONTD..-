#4.Use the function paste to create the following character vectors of length 30:

#a.

paste('Label', 1:30,sep=' ')

#b.

paste('FN',1:30,sep='')
