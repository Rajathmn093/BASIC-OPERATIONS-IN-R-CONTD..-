#A = P(1 + R/100)n

n <- 1:15

p <- 10000

r <- 11.5

a <- p * (1+r/100) ^ n

a

paste('Amount of money owed after ',n, ' years is:',a)