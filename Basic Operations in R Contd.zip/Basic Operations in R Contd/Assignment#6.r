mat <- matrix(c(c(1:5),c(101:105),c(201:205),c(301:305)),nrow=5)

mat
